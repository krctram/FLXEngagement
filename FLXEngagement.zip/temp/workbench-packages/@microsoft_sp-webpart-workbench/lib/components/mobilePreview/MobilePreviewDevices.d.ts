/**
 * Input to the MobilePreview component for which device options to have
 */
export declare const mobilePreviewDevices: any;
//# sourceMappingURL=MobilePreviewDevices.d.ts.map