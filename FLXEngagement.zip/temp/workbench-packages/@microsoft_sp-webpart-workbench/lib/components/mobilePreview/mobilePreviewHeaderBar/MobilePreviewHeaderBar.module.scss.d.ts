declare const styles: {
    mobilePreviewNavBar: string;
    navBarItems: string;
    navBarItemSm: string;
    navBarItemMd: string;
    navBarItem: string;
    'ms-Grid': string;
    navBarItemRight: string;
    mobilePreviewTitle: string;
    mobilePreviewXIcon: string;
    col: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewHeaderBar.module.scss.d.ts.map