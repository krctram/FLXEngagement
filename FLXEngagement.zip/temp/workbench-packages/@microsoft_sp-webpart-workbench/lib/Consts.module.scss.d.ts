declare const styles: {};
export default styles;
//# sourceMappingURL=Consts.module.scss.d.ts.map